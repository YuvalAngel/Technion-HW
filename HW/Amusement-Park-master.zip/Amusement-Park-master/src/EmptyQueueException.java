public class EmptyQueueException extends RuntimeException{
    /**
     * If queue is empty, throw this exception
     */
    public EmptyQueueException() {}

    public EmptyQueueException(String s) {
        super(s);
    }
    public EmptyQueueException(String s, Throwable cause) {
        super(s, cause);
    }
}
