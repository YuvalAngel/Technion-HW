public class Node<E extends Cloneable> implements Cloneable{
    private E value;
    private Node<E> next;
    public Node(E value, Node<E> next) {
        this.value= value;this.next= next;
    }
    public Node(E value) {
        this(value, null);
    }

    public Node() {}

    public E getValue() {
        return value;
    }

    public Node<E> getNext() {
        return next;
    }

    public void setValue(E value) {
        this.value= value;
    }

    public void setNext(Node<E> next) {
        this.next= next;
    }

    public boolean isContained(E other){
        if (this.value.equals(other))
            return true;
        if (this.next == null)
            return false;
        return next.isContained(other);
    }

    /**
     * Checks if two nodes have the same value (Are the same essentially)
     * @param other Node to compare to
     * @return boolean if they are the same or aren't
     */
    @Override
    @SuppressWarnings("unchecked")
    public boolean equals(Object other){
        try {
            return (boolean)this.value.getClass().
                    getMethod("equals", Object.class)
                    .invoke(this.value, ((Node<E>) other).getValue());
        }
        catch (Exception e) {
            return false;
        }
    }

    public boolean hasNext() { return this.next != null; }

    /**
     * @return Final node in current node's list
     */
    public Node<E> getTail() {
        Node<E> tail = this;
        while (tail.getNext() != null)
            tail = tail.getNext();
        return tail;
    }
    @Override
    @SuppressWarnings("unchecked")
    /**
     * Deep copy of each node in this object's list
     */
    public Node<E> clone() {
        try {
            Node<E> cloned =  new Node<>();
            cloned.setValue((E)this.value.getClass()
                    .getMethod("clone").invoke(this.value));
            if (this.next != null)
                cloned.setNext(this.next.clone());
            return cloned;
        }
        catch (Exception e) {
            return null;
        }
    }
}
