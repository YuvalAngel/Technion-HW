public class InvalidInputException extends RuntimeException {
    /**
     * If given input is invalid, for example if given person is null
     * Throw this exception
     */
    public InvalidInputException() {
    }
    public InvalidInputException(String message) {
        super(message);
    }
    public InvalidInputException(String message, Throwable cause) {
        super(message, cause);
    }
}
