public class Person implements Cloneable{
    private final int id;
    private final Person friend;
    private final String name;
    public Person(int id, Person friend, String name) {
        this.id = id;
        this.friend = friend;
        this.name = name;
    }

    public Person(String name, int id, Person friend) {
        this(id, friend, name);
    }

    public Person getFriend() { return this.friend; }

    /**
     * Checks if two people are the same people
     * @param other other person to compare this person to
     * @return boolean value if true or false
     */
    @Override
    public boolean equals(Object other){
        if (other instanceof Person){
            return this.id == ((Person)other).id;
        }
        return false;
    }

    @Override
    /**
     * hashcode function that makes use of the name to create a hashcode
     * By using name, if 2 people have the same attributes
     * Their hashcode will be the same
     */
    public int hashCode() {
        int hash_code = 0;
        for (char c : this.name.toCharArray()) {
            hash_code += c;
        }
        return hash_code;
    }

    @Override
    public String toString() {
        return this.name;
    }

    /**
     * Shallow copy of person
     * @return Person
     */
    @Override
    public Person clone(){
        return new Person(this.id, this.friend, this.name);
    }
}
