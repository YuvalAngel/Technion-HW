public class Park {
    private final static int MAX_RIDES_MUN = 5;
    private final String name;
    private AmusementRide[] rides;
    private int ridesCount;

    public Park(String name) {
        this.name = name;
        rides = new AmusementRide[MAX_RIDES_MUN];
        ridesCount = 0;
    }

    /**
     * Add ride to park
     * @param ride ride to add
     */
    public void add(AmusementRide ride) {
        if (ridesCount == MAX_RIDES_MUN) {
            return;
        }
        rides[ridesCount++] = ride;
    }

    /**
     * Remove ride from park
     * @param ride ride being removed
     */
    public void remove(AmusementRide ride) {
        int i;
        for (i = 0; i < ridesCount; i++) {
            if (rides[i] == ride) {
                rides[i] = null;
                ridesCount--;
                break;
            }
        }
        for (; i < ridesCount; i++) {
            rides[i] = rides[i + 1];
        }
    }
    /**
     * Start letting people into the rides in the park
     */
    public void startRides() {
        for (AmusementRide ride : rides) {
            if (ride != null)
                ride.startRide();
        }
    }

    /**
     * If no friend was given to addPerson as parameter, check if person has friend
     * Call addPerson with friend as parameter with person's friend (can be null)
     * @param ride ride to add person to
     * @param person person to add to ride
     */
    public void addPerson(AmusementRide ride, Person person) {
        Person friend = person.getFriend();
        for (AmusementRide curr : rides) {
            if (curr == ride) {
                curr.addPerson(person, friend);
                break;
            }
        }
    }
}
