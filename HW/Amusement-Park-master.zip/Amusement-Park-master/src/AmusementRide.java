public class AmusementRide {
    private final String name;
    private IsraeliQueue<Person> queue;
    private final int CAPACITY;
    public AmusementRide(String name, int capacity) {
        this.name = name;
        this.CAPACITY = capacity;
        this.queue = new IsraeliQueue<Person>();
    }

    /**
     * Start letting people into the ride
     */
    public void startRide() {
        int numOfPeople;
        Person curr;
        try {
            numOfPeople = Math.min(queue.size(), CAPACITY);
            if (numOfPeople == 0) throw new EmptyQueueException();
            System.out.println("Currently using the ride:");
            for (int i = 0; i < numOfPeople; i++) {
                curr = queue.remove();
                System.out.println(curr);
        }
        } catch (EmptyQueueException e) {
            System.out.println("Ride is empty.");
        }
    }

    /**
     * Add person to this ride's queue
     * @param person person to add
     */
    public void addPerson(Person person, Person friend) {
        queue.add(person, friend);
    }

    public void addPerson(Person person) {
        addPerson(person, null);
    }
}
