import java.lang.reflect.Method;
import java.util.*;
public class IsraeliQueue<E extends Cloneable> implements Cloneable, Iterable<E>{
    /**
     * The class will be implemented using a 2d Node system
     */
    private Node<Node<E>> head;
    private Node<Node<E>> tail;
    private int size = 0;
    /**
     * Add person to queue by hierarchy of conditions:
     * If queue is empty, add to head of queue
     * else if friend is null or not in queue, go to add(Person)
     * else add to end of friend group
     * @param person person to add to queue
     * @param friend friend of person to add to queue
     * @throws InvalidInputException if person is null
     */
    public void add(E person, E friend) throws InvalidInputException {
        if (person == null) throw new InvalidInputException();
        if (this.head == null) {
            this.head = new Node<>(new Node<>(person));
            this.tail = this.head;
            size++;
        }
        else if (friend == null || !this.head.isContained(new Node<>(friend)))
            add(person);
        else {
            Node<E> friend_group = this.find(friend);
            while (friend_group.hasNext())
                friend_group = friend_group.getNext();
            friend_group.setNext(new Node<>(person));
            size++;
        }
    }

    /**
     * Adds person to queue
     * If queue is empty, add to head
     * Otherwise add to tail
     * @param person person to add
     * @throws InvalidInputException if person is null
     */
    public void add(E person) throws InvalidInputException {
        if (person == null) throw new InvalidInputException();
        if (this.head == null) {
            this.head = new Node<>(new Node<>(person));
            this.tail = this.head;
        }
        else {
            this.tail.setNext(new Node<>(new Node<>(person)));
            this.tail = this.tail.getNext();
        }
        size++;
    }

    /**
     * Finds group in queue
     * if person is not in queue or person is null, return null
     * @param person person to find in queue
     * @return group containing said person or null if none
     */
    private Node<E> find(E person) {
        if (person == null || !this.head.isContained(new Node<>(person))) return null;
        Node<Node<E>> temp = this.head;
        while (temp != null) {
            if (temp.getValue().isContained(person)) return temp.getValue();
            temp = temp.getNext();
        }
        return null;
    }

    /**
     * removes first person in queue
     * @return person that was removed
     * @throws EmptyQueueException if queue is empty
     */
    public E remove() throws EmptyQueueException {
        if (this.head == null) throw new EmptyQueueException();
        Node<E> current_group = this.head.getValue();
        E result;
        if (current_group.hasNext())
        {
            result = current_group.getValue();
            current_group = current_group.getNext();
            this.head.setValue(current_group);
        }
        else {
            result = current_group.getValue();
            this.head = this.head.getNext();
        }
        size--;
        return result;
    }

    /**
     * @return first person in queue
     * @throws EmptyQueueException if queue is empty
     */
    public E peek() throws EmptyQueueException {
        /*
        Returns first item in queue, if queue is empty throw exception
         */
        if (size <= 0) throw new EmptyQueueException();
        return this.head.getValue().getValue();
    }
    public int size() { return size; }

    @Override
    @SuppressWarnings("unchecked")
    /**
     * Deep copy of IsraeliQueue object
     */
    public IsraeliQueue<E> clone() {
        try {
            IsraeliQueue<E> result = (IsraeliQueue<E>) super.clone();
            result.head = this.head.clone();
            result.tail = result.head.getTail();
            return result;
        }
        catch (Exception e) {
            return null;
        }
    }

    /**
     * Iterator to allow a foreach loop of IsraeliQueue
     * This iterator is implemented using an anonymous class
     */
    @Override
    public Iterator<E> iterator() {
        return new Iterator<>(){
            private Node<Node<E>> current = head;
            private Node<E> current_group = current.getValue();
             @Override
            public boolean hasNext() {
                 return current != null;
             }
             @Override
             /**
              * If first group has people, keep going through group
              * Otherwise progress to next group
              */
            public E next() {
                 if (hasNext()) {
                     E value = current_group.getValue();
                     if (current_group.getNext() != null)
                        current_group = current_group.getNext();
                     else
                     {
                         current = current.getNext();
                         if (current != null)
                            current_group = current.getValue();
                     }
                     return value;
                 }
                 else return null;
             }
        };
    }
}
