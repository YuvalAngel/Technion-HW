public class Game {
    private final int MAX_GENERATIONS;

    private final Board board;


    Game(int rows, int cols, int seed, int range, int maxGenerations) {
        this.board = new Board(rows, cols, seed, range);
        this.MAX_GENERATIONS = maxGenerations;
    }

    void runGame(){
        Board lastBoard = null;
        Board currentGameBoard = this.board;
        try {
            currentGameBoard = (Board)this.board.clone();
        } catch (CloneNotSupportedException _) {}
        System.out.println("Generation 0:");
        System.out.print(currentGameBoard.toString());
        for (int i = 1; i <= MAX_GENERATIONS; i++) {
            try {
                lastBoard = (Board)currentGameBoard.clone();
                currentGameBoard.nextGeneration();
            } catch (CloneNotSupportedException _) {}
            System.out.println("Generation " + i + ":");
            System.out.print(currentGameBoard.toString());
            if (currentGameBoard.allDead()) {
                System.out.println("All cells are dead.");
                return;
            }
            if (lastBoard.equals(currentGameBoard)) {
                System.out.println("Cells have stabilized.");
                return;
            }
        }

        System.out.println("The generation limitation was reached.");
    }
}
