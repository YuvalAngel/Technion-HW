import java.util.Random;
public class Board implements Cloneable{
    //Class Constants:
    private static final int RESET_NEIGHBORS = 0;
    private static final int DIGIT_FACTOR = 10;
    //Class Parameters:
    private Cell[][] board;
    private final int rows;
    private final int cols;
    private Random rand;
    //Constructor:
    public Board(int rows, int cols, int seed, int range){
        /*
        Roll random number using range parameter
        If rolled number is even, set state to dead
        Otherwise, cell is healthy
        @Param seed - seed used to roll random numbers
        @Param range - range to roll random number from
         */
        board = new Cell[rows][cols];
        this.rows = rows;
        this.cols = cols;
        this.rand = new Random(seed);
        for (int row = 0; row < rows; row++)
            for (int col = 0; col < cols; col++){
                board[row][col] = new Cell();
                int current = this.rand.nextInt(range);
                if (current % 2 == 0) board[row][col].setDead();
                else board[row][col].setHealthy();
            }
    }
    public Board(int rows, int cols, Cell[][] board){
        this.rows = rows;
        this.cols = cols;
        this.board = board;
    }
    //Functions:
    private boolean in_bounds(int row, int col){
        return row >= 0 && row < this.rows && col >= 0 && col < this.cols;
    }
    private int[] checkNeighbors(int row, int col){
        /*
        Gets index in board
        Returns how many neighbors it has of each state
        @Param: row - row of selected cell
        @Param col - col of selected cell
        @Return 1x4 array containing amount of each state in neighboring cells
         */
        int[] neighbors = {RESET_NEIGHBORS, RESET_NEIGHBORS, RESET_NEIGHBORS, RESET_NEIGHBORS};
        for(int i = row - 1; i <= row + 1 && i < this.rows; i++)
            for (int j = col - 1; j <= col + 1 && j < this.cols; j++)
                if ((i != row || j != col) && in_bounds(i, j))
                    neighbors[board[i][j].stateNumber()]++;
        return neighbors;
    }
    public void nextGeneration(){
        /*
        Progress board to next generation
        @Return void
         */
        Cell[][] newBoard = new Cell[this.rows][this.cols];
        for (int row = 0; row < this.rows; row++){
            for (int col = 0; col < this.cols; col++){
                int[] neighbors = this.checkNeighbors(row, col);
                newBoard[row][col] = board[row][col].nextGeneration(neighbors);
            }
        }
        this.board = newBoard;
    }
    public boolean allDead() {
        /*
        Checks and returns whether all cells are dead
        @Return whether all cells are dead
         */
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.cols; j++) {
                if (board[i][j].state != CellState.DEAD)
                    return false;
            }
        }
        return true;
    }
    //Override Functions:
    @Override
    public String toString(){
        String description = "";
        for (int row = 0; row < this.rows; row++)
            for (int col = 0; col < this.cols; col++) {
                description = description.concat(board[row][col].toString());
                if (col != this.cols - 1) description = description.concat(" ");
                else description = description.concat("\n");
            }
        return description;
    }
    @Override
    public boolean equals(Object o){
        if (o instanceof Board){
            Board other = (Board) o;
            if (this.rows != other.rows || this.cols != other.cols) return false;
            for (int row = 0; row < this.rows; row++)
                for (int col = 0; col < this.cols; col++)
                    if (!this.board[row][col].equals(other.board[row][col])) return false;
        }
        return true;
    }
    @Override
    public int hashCode() {
        int ret = 0, factor = DIGIT_FACTOR;
        ret += factor * this.rows;
        factor *= DIGIT_FACTOR;
        ret += factor * this.cols;
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < this.cols; j++) {
                factor *= DIGIT_FACTOR;
                ret += board[i][j].hashCode();
            }
        }
        return ret;
    }
    @Override
    public Object clone() throws CloneNotSupportedException{
        Cell[][] newBoard = this.board.clone();
        for (int row = 0; row < this.rows; row++)
            for (int col = 0; col < this.cols; col++)
                newBoard[row][col] = (Cell) board[row][col].clone();
        return new Board(this.rows, this.cols, newBoard);
    }
}
