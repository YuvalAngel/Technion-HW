public enum CellState {
    //Enum Variants:
    DEAD("-"),
    HEALTHY("H"),
    SICK("S"),
    DYING("D");

    // Enum Constants:
    private final static int DEAD_NUMBER = 0;
    private final static int HEALTHY_NUMBER = 1;
    private final static int SICK_NUMBER = 2;
    private final static int DYING_NUMBER = 3;

    //Enum Variables:
    private final String state;

    //Enum Constructor:
    CellState(String state_num) { this.state = state_num; }

    //Enum Functions:
    public int getStateNum() {
        return switch (state) {
            case "-" -> DEAD_NUMBER;
            case "H" -> HEALTHY_NUMBER;
            case "S" -> SICK_NUMBER;
            default -> DYING_NUMBER;
        };
    }
    @Override
    public String toString() { return state;}
}
