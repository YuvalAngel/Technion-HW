public class Cell implements Cloneable{
    //Class Constants:
    private static final int PROGRESS_DEAD_TO_HEALTHY = 3;
    private static final int TOO_LITTLE_HEALTHY = 2;
    private static final int TOO_MANY_HEALTHY = 3;
    private static final int HEALTHY_CELL_TOO_MANY_SICK = 3;
    private static final int SICK_CELL_TOO_MANY_SICK = 2;
    private static final int DYING_CELL_TOO_MANY_SICK = 1;
    private static final int DYING_CELL_EXACT_HEALTHY_CELLS = 3;
    //Class Variables:
    public CellState state;
    //Constructors:
    public Cell() {
        this.state = CellState.DEAD;
    }
    public Cell(CellState state) {this.state = state;}
    //Functions:
    public void setDead(){ this.state = CellState.DEAD; }
    public void setHealthy(){ this.state = CellState.HEALTHY;}
    public int stateNumber(){ return this.state.getStateNum();}
    public Cell nextGeneration(int[] neighbors){
        /*
        Find what next generation of this cell is, and return new cell of that state
        @Param neighbors - array with amount of neighbors of each state for this cell
        @Param healthy - index of healthy cells in neighbors
        @param sick - index of sick cells in neighbors
        @Return new cell with next generation state of current cell
         */
        int healthy = CellState.HEALTHY.getStateNum();
        int sick = CellState.SICK.getStateNum();
        switch (this.state) {
            /*
            For each current state, check conditions as stated in task
             */
            case DEAD:
                if (neighbors[healthy] == PROGRESS_DEAD_TO_HEALTHY)
                    return new Cell(CellState.HEALTHY);
                else return new Cell(CellState.DEAD);
            case HEALTHY:
                if (neighbors[healthy] < TOO_LITTLE_HEALTHY ||
                        neighbors[healthy] > TOO_MANY_HEALTHY ||
                        neighbors[sick] > HEALTHY_CELL_TOO_MANY_SICK) {
                    return new Cell(CellState.SICK);
                }
                break;
            case SICK:
                if (neighbors[healthy] < TOO_LITTLE_HEALTHY ||
                        neighbors[healthy] > TOO_MANY_HEALTHY
                        || neighbors[sick] > SICK_CELL_TOO_MANY_SICK)
                    return new Cell(CellState.DYING);
                break;
            case DYING:
                if (neighbors[healthy] != DYING_CELL_EXACT_HEALTHY_CELLS ||
                        neighbors[sick] > DYING_CELL_TOO_MANY_SICK)
                    return new Cell(CellState.DEAD);
                break;
        }
        return new Cell(CellState.HEALTHY);
    }
    //Override functions:
    @Override
    public String toString() {
        return this.state.toString();
    }
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Cell) {
            Cell cell = (Cell) obj;
            return this.state == cell.state;
        }
        return false;
    }
    @Override
    public int hashCode() {
        return this.state.getStateNum();
    }
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
