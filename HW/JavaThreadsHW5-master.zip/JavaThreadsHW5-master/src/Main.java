public class Main {

    public static void main(String[] args){
        for (int i=1; i <= 1; i++) {    // output is deterministic
            try {
                System.out.println("Test 1, iteration " + i + " starts");
                test1();
            } catch (Exception e) {
                System.out.println("exception " + e);
            }
            finally {
                System.out.println("Test 1, iteration " + i + " done");
                System.out.println("--------------------------------------------");
            }
        }

        for (int i=1; i <= 5; i++) {    // output is non deterministic
            try {
                System.out.println("Test 2, iteration " + i + " starts");
                test2();
            } catch (Exception e) {
                System.out.println("exception " + e);
            }
            finally {
                System.out.println("Test 2, iteration " + i + " done");
                System.out.println("--------------------------------------------");
            }
        }
    }

    public static void test1(){

        Stock list = new Stock(3);

        Producer producer = new Producer(list, 1, 2000);
        Consumer consumer = new Consumer(list, 2, 0);

        producer.start();
        consumer.start();

        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException e) {
            throw new RuntimeException("Problem occurred in the cpu");
        }
    }

    public static void test2() {

        Stock list = new Stock(3);

        Producer producer = new Producer(list, 1, 330);
        Consumer consumer = new Consumer(list, 2, 500);

        producer.start();
        consumer.start();

        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException e) {
            throw new RuntimeException("Problem occurred in the cpu");
        }
    }
}