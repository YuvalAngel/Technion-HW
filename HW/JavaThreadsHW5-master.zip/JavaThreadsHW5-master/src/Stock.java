import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Stock {
    private final LinkedList<Integer> products = new LinkedList<>();
    private final int maxSize;
    private int pastItems = 0;
    private int currentItem = 0;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition notEmpty = lock.newCondition();
    private final Condition notFull = lock.newCondition();

    public Stock(int maxSize){
        this.maxSize = maxSize;
    }

    /**
     * consume item from products
     * if products is empty, wait until there are products, then consume
     * @param item id of current thread
     */
    public void consume(int item){
        lock.lock();
        try {
            while (products.isEmpty()) {
                try {
                    notEmpty.await();
                }
                catch (InterruptedException _) {}
            }
            products.removeFirst();
            System.out.println("Consumer " + item + " consumed item: " + currentItem);
            currentItem++;
            notFull.signal();
        }
        finally {
            lock.unlock();
        }
    }

    /**
     * produce a new item to products
     * if products is full, wait until it isn't, then add product
     * @param item id of current thread
     */
    public void produce(int item){
        lock.lock();
        try {
            while (products.size() >= maxSize) {
                try {
                    notFull.await();
                }
                catch (InterruptedException _) {}
            }
            products.add(pastItems);
            System.out.println("Producer " + item + " produced new item: " + pastItems);
            pastItems++;
            notEmpty.signal();
        }
        finally {
            lock.unlock();
        }
    }
}
