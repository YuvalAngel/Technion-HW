public class Consumer extends Thread {
    private final Stock products;
    private final int id;
    private static final int MAX_CONSUMPTIONS = 5;
    private final int waitingTime;

    public Consumer(Stock products, int id, int waitingTime) {
        this.products = products;
        this.id = id;
        this.waitingTime = waitingTime;
    }

    public void run() {
        for (int i=0; i < MAX_CONSUMPTIONS; i++){
            try {
                products.consume(id);
                if (waitingTime > 0)
                    Thread.sleep(waitingTime);
            } catch (InterruptedException | RuntimeException e) {
                e.printStackTrace();
            }
        }
    }
}
