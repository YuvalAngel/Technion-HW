public enum Genre {
    DRAMA("Drama"),
    SCIENCE_FICTION("Science Fiction"),
    HISTORY("History Fiction"),
    FANTASY("Fantasy");
    private final String genre;
    Genre(String genre) {
        this.genre = genre;
    }
    public String getGenre() {
        return this.genre;
    }

}
