public class Member {
    private final String name;
    private final LibraryCard libraryCard;

    public Member(String name, LibraryCard libraryCard) {
        this.name = name;
        this.libraryCard = libraryCard;
    }

    public String getName() {
        return name;
    }

    public LibraryCard getLibraryCard() {
        return libraryCard;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Checked-out books:\n" + libraryCard.getBooksStr();
    }
}
