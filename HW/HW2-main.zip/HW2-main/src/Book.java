public class Book {
    protected final String title;
    protected Author author;
    protected Genre genre;
    private final String id;
    private boolean bookBorrowed = false;
    public Book(String title, Author author, Genre genre, int id) {
        this.author = author;
        this.title = title;
        this.genre = genre;
        this.id = "BN" + id;
    }
    public String getBook(){
        return ("Title: " + this.title + ", Genre: " + this.genre.getGenre() +
                ", Author: " + this.author.getName() + ".");
    }
    public String getTitle(){
        return this.title;
    }
    public Genre getGenre(){
        return this.genre;
    }
    public Author getAuthor(){
        return this.author;
    }
    public boolean equals(Book other){
        /*
        This function checks if given book is the same as this book
         */
        if (!this.getTitle().equals(other.getTitle())) return false;
        if (!this.genre.equals(other.getGenre())) return false;
        if (!this.author.equals(other.getAuthor())) return false;
        return true;

    }
    public boolean isBookBorrowed(){
        return this.bookBorrowed;
    }


    public boolean isID(String id){
        /*
        This function checks if the book has the given ID
         */
        return this.id.equals(id);
    }

    public void borrowBook() {
        /*
        This function sets the bookBorrowed attribute to true
         */
        this.bookBorrowed = true;
    }
    public void returnBook() {
        /*
        This function sets the bookBorrowed attribute to false
         */
        this.bookBorrowed = false;
    }

}
