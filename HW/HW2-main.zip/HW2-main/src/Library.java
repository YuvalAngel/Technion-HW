public class Library {
    private int totalNumOfBooks = 0;
    private int numOfBooks = 0;
    private int numOfMembers = 0;
    private final int MAX_MEMBERS = 5;
    private final Book[] books = new Book[20];
    private final Member[] members = new Member[MAX_MEMBERS];
    private final String name;
    private int cardsCreated = 0;

    Library(String name) {
        this.name = name;
    }

    public void addBook(String name, Genre genre, String authorName, String bio) {
        /*
        This function adds a book to the library
        If the given author is new, create author in database
        Then, create a new book
         */
        if (numOfBooks < books.length) {
            Author bookAuthor = this.findAuthor(authorName);
            if (bookAuthor == null || !bookAuthor.getBiography().equals(bio))
                bookAuthor = new Author(authorName, bio);
            books[numOfBooks++] = new Book(name, bookAuthor, genre, totalNumOfBooks);
            totalNumOfBooks++;
        } else {
            System.out.println("Library is full, cannot add more books.");
        }
    }

    public void removeBook(String name, Genre genre, String authorName, String bio) {
        /*
        This function removes a book from library
        If book is borrowed or does not exist, print not possible and exit
        Otherwise, remove book
         */
        if (numOfBooks <= 0) {
            System.out.println("No such book exists.");
        } else {
            Book currentBook = this.findBook(name, genre);
            if (currentBook == null || currentBook.isBookBorrowed())
                System.out.println("No such book exists.");
            else
                this.removeBook(currentBook);
        }
    }

    private void removeBook(Book book) {
        /*
        This is an aux function for removeBook
        If found that book is available to be removed, find book in library and remove it
         */
        boolean after_book = false;
        for (int i = 0; i < numOfBooks; i++) {
            if (after_book) {
                books[i] = books[i + 1];
            } else if (book == books[i]) {
                books[i] = books[i + 1];
                numOfBooks--;
                after_book = true;
            }
        }
    }

    public void printBooks() {
        /*
        Prints description of all books in library
         */
        if (numOfBooks == 0)
            System.out.println("No books in the library currently.");
        else
            for (int i = 0; i < numOfBooks; i++) {
                if (books[i] != null && !books[i].isBookBorrowed())
                    System.out.println(books[i].getBook());
            }
    }

    private Author findAuthor(String authorName) {
        /*
        This function searches for an author in library by name
        If exists, return author
        If not, returns null
         */
        for (int i = 0; i < numOfBooks; i++) {
            if (books[i].author.getName().equals(authorName)) {
                return books[i].getAuthor();
            }
        }
        return null;
    }

    public Author getAuthor(String id) {
        /*
        Searches for an author in library by book ID
         */
        for (int i = 0; i < numOfBooks; i++) {
            if (books[i].isID(id)) return books[i].getAuthor();
        }
        return null;
    }

    private Book findBook(String name, Genre genre) {
        /*
        This function searches for a book in library by name and biography
        If exists, return book
        If not, return null
         */
        for (int i = 0; i < numOfBooks; i++) {
            if (books[i].getTitle().equals(name) && books[i].getGenre().equals(genre))
                return books[i];
        }
        return null;
    }

    private Book findBook(String id) {
        /*
        This function searches for a book in library by ID
        If exists, return book
        If not, return null
         */
        for (int i = 0; i < numOfBooks; i++) {
            if (books[i].isID(id))
                return books[i];
        }
        return null;
    }

    public void addMember(String name, int numOfBooks) {
        /*
        This function creates and adds a new member to the library
        Input: the new member's name and amount of books they're allowed to borrow
         */
        if (numOfMembers >= MAX_MEMBERS) {
            System.out.println("Library is full, cannot add more members.");
            return;
        }
        this.members[numOfMembers] = new Member(name, new LibraryCard(numOfBooks, cardsCreated));
        numOfMembers++;
        cardsCreated++;
    }

    public void removeMember(String id) {
        /*
        This function removes a member from the library
         */
        int i = 0;
        for (; i < numOfMembers; i++) {
            if (members[i].getLibraryCard().getId().equals(id)) {
                LibraryCard card = members[i].getLibraryCard();
                card.removeAll();
                members[i] = null;
                break;
            }
        }
        ++i;
        for (; i < numOfMembers; i++) {
            members[i - 1] = members[i];
        }
        members[numOfMembers - 1] = null;
        numOfMembers--;
    }

    public void printMember(String id) {
        /*
        This function prints the details of a member given their card's ID
         */
        boolean noneFound = true;
        for (Member member : members) {
            if (member != null && member.getLibraryCard().getId().equals(id)) {
                noneFound = false;
                System.out.print(member.toString());
                break;
            }
        }
        if (noneFound) {
            System.out.println("No such member exists.");
        }
    }

    private Member findMember(String id) {
        boolean exists = false;
        for (Member member : members) {
            if (member.getLibraryCard().getId().equals(id)) {
                exists = true;
                return member;
            }
        }
        return null;
    }

    public void checkOutBook(String bookID, String cardID) {
        /*
        This function checks out a book with the given ID for the card with the given ID
         */
        Book book = findBook(bookID);
        if (book == null) {
            System.out.println("No such book exists.");
            return;
        }
        if (book.isBookBorrowed()) {
            System.out.println("The book is already checked-out.");
            return;
        }
        Member member = findMember(cardID);
        if (member == null) {
            System.out.println("No such member exists.");
            return;
        }
        LibraryCard card = member.getLibraryCard();
        if (card.isAtLimit()) {
            System.out.println("The member reached the limit.");
            return;
        }
        book.borrowBook();
        card.addBook(book);
    }

    public void returnBook(String bookID, String cardID) {
        /*
        This function returns a book with the given ID from the card with th given ID
         */
        Member member = findMember(cardID);
        if (member == null) {
            System.out.println("No such member exists.");
            return;
        }
        Book book = member.getLibraryCard().findBook(bookID);
        if (book == null) {
            System.out.println("No such book exists.");
        }
        member.getLibraryCard().removeBook(book);

    }
}