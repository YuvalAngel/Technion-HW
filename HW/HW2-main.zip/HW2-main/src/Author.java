public class Author {
    private final String name;
    private final String biography;
    public Author(String name, String bio){
        this.name = name;
        this.biography = bio;
    }
    public boolean equals(Author other){
        if (this.name.equals(other.name) && this.biography.equals(other.biography))
            return true;
        return false;
    }
    public String getName(){
        return this.name;
    }
    public String getBiography(){
        return this.biography;
    }
}
