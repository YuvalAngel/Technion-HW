public class LibraryCard {
    private String id;
    private final int MAX_BOOKS;
    private int numOfBooks = 0;
    private Book[] books;

    LibraryCard(String id, int numOfBooks, int cardsCreated) {
        this.id = id;
        this.MAX_BOOKS = numOfBooks;
        this.books = new Book[numOfBooks];
    }

    LibraryCard(int numOfBooks, int cardsCreated) {
        this("LC" + cardsCreated, numOfBooks, cardsCreated);
    }


    public String getId() {
        return id;
    }

    public Book[] getBooks() {
        return books;
    }


    public String getBooksStr() {
        /*
        This function returns a list of the books borrowed by the card in the following format:
        "Title: <title>, Genre: <genre>, Author: <authorName>.\n"
         */
        String ret = "";
        for (Book book : books) {
            if (book != null && book.isBookBorrowed()) { //otherwise it's a placeholder
                ret += book.getBook() + "\n";
            }
        }
        return ret;
    }


    public boolean isAtLimit() {
        /*
        This function returns whether the card has borrowed as many books as it can
         */
        return numOfBooks >= MAX_BOOKS;
    }

    private int findBook(Book book) {
        /*
        This function searches for a book in card
        If exists, return index
        If not, return -1
         */
        for (int i = 0; i < MAX_BOOKS; i++) {
            if (books[i].equals(book))
                return i;
        }
        return -1;
    }

    public Book findBook(String id) {
        /*
        This function searches for a book in card
        If exists, return book
        If not, return null
         */
        for (Book curr : books) {
            if (curr.isID(id))
                return curr;
        }
        return null;
    }

    public void addBook(Book book) {
        /*
        This function adds a new book to the card
         */
        if (!isAtLimit()) {
            books[numOfBooks] = book;
            numOfBooks++;
        }
    }

    public void removeBook(Book book) {
        /*
        This function removes a book from the card
         */
        int book_idx = findBook(book);
        if (book_idx == -1) {
            return;
        }
        books[book_idx].returnBook();
        books[book_idx] = null;
        for (int i = book_idx + 1; i < numOfBooks; i++) {
            books[i - 1] = books[i];
        }
        books[numOfBooks] = null;
        numOfBooks--;
    }
    public void removeAll() {
        /*
        This function removes all books from the card
         */
        for (int i = 0; i < numOfBooks; i++) {
            books[i].returnBook();
            books[i] = null;
        }
        numOfBooks = 0;
    }
}
