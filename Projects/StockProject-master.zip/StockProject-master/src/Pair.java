public class Pair <T extends Comparable<T>, K extends
        Comparable<K>> implements Comparable<Pair<T,K>> {
    private T value1;
    private K value2;
    public Pair(T value1, K value2) {
        this.value1 = value1;
        this.value2 = value2;
    }
    public Pair() {
        this.value1 = null;
        this.value2 = null;
    }
    @Override
    public int compareTo(Pair<T,K> p) {
        if (p == null) return 0;
        if (this.value1.equals(p.value1)) {
            return this.value2.compareTo(p.value2);
        }
        return this.value1.compareTo(p.value1);
    }
    public T getValue1() { return value1; }
    public K getValue2() { return value2; }
    public void setValue1(T value1) { this.value1 = value1; }
    public void setValue2(K value2) { this.value2 = value2; }
    @Override
    public boolean equals(Object o) {
        if (o instanceof Pair) {
            Pair<T,K> p = (Pair<T,K>) o;
            return this.value1.equals(p.value1) && this.value2.equals(p.value2);
        }
        return false;
    }
}
