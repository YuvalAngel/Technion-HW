public class Price23Tree extends TwoThreeTree<Pair<Float, String>, Stock>{
    public Price23Tree() {
        super();
        MINKEY = new Pair<>();
        MINKEY.setValue1(0f);
        MINKEY.setValue2("");
        MAXKEY = new Pair<>();
        MAXKEY.setValue1(Float.MAX_VALUE);
        MAXKEY.setValue2("ZZZZZZZZZZZZZZZZZZZZ");
    }
    public void insert(Stock stock){
        super.insert(new Pair<>(stock.getPrice(), stock.getStockID()), stock);
    }
    public void remove(Float price, String stockID){
        super.remove(new Pair<>(price, stockID));
    }
    protected TreeNode<Pair<Float, String>, Stock> findFirstNodeAboveValue
            (TreeNode<Pair<Float, String>, Stock> x, Pair<Float, String> value) {
        if (isLeaf(x)) return x;
        if (value.compareTo(x.getLeft().getKey()) < 0)
            return findFirstNodeAboveValue(x.getLeft(), value);
        else if (value.compareTo(x.getMiddle().getKey()) < 0)
            return findFirstNodeAboveValue(x.getMiddle(), value);
        else if (x.getRight() != null) return findFirstNodeAboveValue(x.getRight(), value);
        return rightSentinel;
    }
    private int countLower(TreeNode<Pair<Float, String>, Stock> x,
                           Pair<Float, String> key) {
        if (x == null) return 0;
        if (isLeaf(x)) {
            if (x.getKey().compareTo(key) < 0) return 1;
            else return 0;
        }
        if (key.compareTo(x.getLeft().getKey()) <= 0)
            return countLower(x.getLeft(), key);
        else if (key.compareTo(x.getMiddle().getKey()) <= 0)
            return x.getLeft().getCount() + countLower(x.getMiddle(), key);
        return x.getLeft().getCount() + x.getMiddle().getCount()
                + countLower(x.getRight(), key);
    }
    public int getAmountStocksInPriceRange(Float price1, Float price2) {
        TreeNode<Pair<Float, String>, Stock> first =
                findFirstNodeAboveValue(root, new Pair<>(price1, ""));
        TreeNode <Pair<Float, String>, Stock> second =
                findFirstNodeAboveValue(root, new Pair<>(price2, ""));
        if (first == second && price1 <= first.getKey().getValue1() && first.getKey().getValue1() <= price2)
            return 1;
        else if (first == second) return 0;
        if (first.getKey().getValue1() > price2) return 0;
        return countLower(root, second.getKey()) - countLower(root, first.getKey());
    }
    public String[] getStocksInPriceRange(Float price1, Float price2) {
        TreeNode<Pair<Float, String>, Stock> first = findFirstNodeAboveValue(root, new Pair<>(price1, ""));
        int len = getAmountStocksInPriceRange(price1, price2);
        if (len == 0) return new String[0];
        String[] res = new String[len];
        for (int i = 0; i < res.length; i++) {
            res[i] = first.getValue().getStockID();
            first = first.getNext();
        }
        return res;
    }
}