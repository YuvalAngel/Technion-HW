public class TwoThreeTree <T extends Comparable<T>, K>{
    protected TreeNode<T, K> root;
    protected T MINKEY, MAXKEY;
    protected TreeNode<T, K> leftSentinel, rightSentinel;
    protected int counter;
    protected TwoThreeTree() {
        root = null;
        counter = 0;
    }
    protected void init() {
        TreeNode<T, K> x = new TreeNode<>();
        leftSentinel = new TreeNode<>();
        rightSentinel = new TreeNode<>();
        leftSentinel.setKey(MINKEY);
        rightSentinel.setKey(MAXKEY);
        leftSentinel.setParent(x);
        rightSentinel.setParent(x);
        leftSentinel.setCount(0);
        rightSentinel.setCount(0);
        x.setKey(MAXKEY);
        x.setLeft(leftSentinel);
        x.setMiddle(rightSentinel);
        leftSentinel.setNext(rightSentinel);
        rightSentinel.setPrev(leftSentinel);
        root = x;
    }
    protected TreeNode<T, K> Successor(TreeNode<T, K> x) {
        if (x == null) return null;
        TreeNode<T, K> z = x.getParent();
        while (z != null && (x == z.getRight() ||
                (z.getRight() == null && x == z.getMiddle()))) {
            x = z;
            z = z.getParent();
        }
        if (z == null) return null;
        TreeNode<T, K> y;
        if (x == z.getLeft())
            y = z.getMiddle();
        else y = z.getRight();
        if (y == null) return null;
        while (!isLeaf(y)) y = y.getLeft();
        if (notSentinel(y)) return y;
        return null;
    }
    protected TreeNode<T, K> Predecessor(TreeNode<T, K> x) {
        if (x == null) return null;
        TreeNode<T, K> z = x.getParent();
        while (z != null && x == z.getLeft()) {
            x = z;
            z = z.getParent();
        }
        if (z == null) return null;
        TreeNode<T, K> y;
        if (x == z.getRight())
            y = z.getMiddle();
        else y = z.getLeft();
        if (y == null) return null;
        while (!isLeaf(y)) {
            if (y.getRight() != null)
                y = y.getRight();
            else y = y.getMiddle();
        }
        if (notSentinel(y)) return y;
        return null;
    }
    protected K search(T key){
        if (counter == 0) return null;
        TreeNode<T, K> s = searchNode(root, key);
        if (s == null) return null;
        return s.getValue();
    }
    protected TreeNode<T, K> searchNode(TreeNode<T, K> x, T key) {
        if (isLeaf(x)) {
            if (key.equals(x.getKey())) return x;
            else return null;
        }
        if (key.compareTo(x.getLeft().getKey()) <= 0)
            return searchNode(x.getLeft(), key);
        else if (x.getMiddle() != null &&
                key.compareTo(x.getMiddle().getKey()) <= 0)
            return searchNode(x.getMiddle(), key);
        else if (x.getRight() != null)
            return searchNode(x.getRight(), key);
        return null;
    }
    protected void updateKey(TreeNode<T, K> x) {
        if (notSentinel(x.getLeft()))
            x.setKey(x.getLeft().getKey());
        if (x.getMiddle() != null && notSentinel(x.getMiddle()))
            x.setKey(x.getMiddle().getKey());
        if (x.getRight() != null && notSentinel(x.getRight()))
            x.setKey(x.getRight().getKey());
        updateCount(x);
    }
    protected void updateCount(TreeNode<T, K> x) {
        int count = 0;
        if (x.getLeft() != null && notSentinel(x.getLeft()))
            count += x.getLeft().getCount();
        if (x.getMiddle() != null && notSentinel(x.getMiddle()))
            count += x.getMiddle().getCount();
        if (x.getRight() != null && notSentinel(x.getRight()))
            count += x.getRight().getCount();
        x.setCount(count);
    }
    protected boolean notSentinel(TreeNode<T, K> x) {
        return x.getKey() != MINKEY && x.getKey() != MAXKEY;
    }
    protected boolean isLeaf(TreeNode<T, K> x) {
        boolean isNormalLeaf = (x.getLeft() == null) &&
                (x.getMiddle() == null) && (x.getRight() == null);
        if (isNormalLeaf) return true;
        if (x.getLeft() != null && notSentinel(x.getLeft())) return false;
        if (x.getMiddle() != null && notSentinel(x.getMiddle())) return false;
        if (x.getRight() != null && notSentinel(x.getRight())) return false;
        return true;
    }
    protected void setChildren(TreeNode<T, K> x, TreeNode<T, K> l, TreeNode<T, K> m, TreeNode<T, K> r) {
        x.setLeft(l);
        x.setMiddle(m);
        x.setRight(r);
        l.setParent(x);
        if (m != null)
            m.setParent(x);
        if (r != null)
            r.setParent(x);
        updateKey(x);
    }
    protected void setPrevNext(TreeNode<T, K> first, TreeNode<T, K> second) {
        if (first != null) first.setNext(second);
        if (second != null) second.setPrev(first);
    }
    protected TreeNode<T, K> insertAndSplit(TreeNode<T, K> x, TreeNode<T, K> z) {
        TreeNode<T, K> l = x.getLeft();
        TreeNode<T, K> m = x.getMiddle();
        TreeNode<T, K> r = x.getRight();
        if (r == null) {
            if (z.getKey().compareTo(l.getKey()) < 0) {
                setChildren(x, z, l, m);
            }
            else if (z.getKey().compareTo(m.getKey()) < 0)
                setChildren(x, l, z, m);
            else
                setChildren(x, l, m, z);
            return null;
        }
        TreeNode<T, K> y = new TreeNode<>();
        if (z.getKey().compareTo(l.getKey()) < 0) {
            setChildren(x, z, l, null);
            setChildren(y, m, r, null);
        }
        else if (z.getKey().compareTo(m.getKey()) < 0) {
            setChildren(x, l, z, null);
            setChildren(y, m, r, null);
        }
        else if (z.getKey().compareTo(r.getKey()) < 0) {
            setChildren(x, l, m, null);
            setChildren(y, z, r, null);
        }
        else {
            setChildren(x, l, m, null);
            setChildren(y, r, z, null);
        }
        return y;
    }
    protected TreeNode<T, K> borrowOrMerge(TreeNode<T, K> y) {
        TreeNode<T, K> z = y.getParent();
        if (y == z.getLeft()) {
            TreeNode<T, K> x = z.getMiddle();
            if (x.getRight() != null) {
                setChildren(y, y.getLeft(), x.getLeft(), null);
                setChildren(x, x.getMiddle(), x.getRight(), null);
            }
            else {
                setChildren(x, y.getLeft(), x.getLeft(),x.getMiddle());
                setChildren(z, x, z.getRight(), null);
            }
            return z;
        }
        if (y == z.getMiddle()) {
            TreeNode<T, K> x = z.getLeft();
            if (x.getRight() != null) {
                setChildren(y, x.getRight(), y.getLeft(), null);
                setChildren(x, x.getLeft(), x.getMiddle(), null);
            }
            else {
                setChildren(x, x.getLeft(), x.getMiddle(),y.getLeft());
                setChildren(z, x, z.getRight(), null);
            }
            return z;
        }
        TreeNode<T, K> x = z.getMiddle();
        if (x.getRight() != null) {
            setChildren(y, x.getRight(), y.getLeft(), null);
            setChildren(x, x.getLeft(), x.getMiddle(), null);
        }
        else {
            setChildren(x, x.getLeft(), x.getMiddle(),y.getLeft());
            setChildren(z, z.getLeft(), x, null);
        }
        return z;
    }
    protected void insert(T key, K value){
        TreeNode<T, K> z = new TreeNode<>(key, value);
        counter++;
        insert(z);
        TreeNode<T, K> temp = Predecessor(z);
        if (temp == null)
            temp = leftSentinel;
        setPrevNext(temp, z);
        temp = Successor(z);
        if (temp == null)
            temp = rightSentinel;
        setPrevNext(z, temp);
    }
    protected void insert(TreeNode<T, K> z) {
        TreeNode<T, K> y = root;
        while (!isLeaf(y)) {
            if (z.getKey().compareTo(y.getLeft().getKey()) < 0)
                y = y.getLeft();
            else if ((y.getMiddle() != null && z.getKey().compareTo(y.getMiddle().getKey()) < 0)
                    || y.getRight() == null)
                y = y.getMiddle();
            else if (y.getRight() != null) y = y.getRight();
        }
        TreeNode<T, K> x = y.getParent();
        if (x == null) x = root;
        z = insertAndSplit(x, z);
        while (x != root) {
            x = x.getParent();
            if (z != null) z = insertAndSplit(x, z);
            else updateKey(x);
        }
        if (z != null) {
            TreeNode<T, K> w = new TreeNode<>();
            setChildren(w, x, z, null);
            root = w;
        }
    }
    protected void remove(TreeNode<T, K> x) {
        TreeNode<T, K> y = x.getParent();
        if (x == y.getLeft())
            setChildren(y, y.getMiddle(), y.getRight(), null);
        else if (x == y.getMiddle())
            setChildren(y, y.getLeft(), y.getRight(), null);
        else
            setChildren(y, y.getLeft(), y.getMiddle(), null);
        while (y != null) {
            if (y.getMiddle() != null) {
                updateKey(y);
                y = y.getParent();
            }
            else {
                if (y != root)
                    y = borrowOrMerge(y);
                else {
                    root = y.getLeft();
                    y.getLeft().setParent(null);
                    y = null;
                }
            }
        }
    }
    protected void remove(T key) {
        TreeNode<T, K> z = searchNode(root, key);
        TreeNode<T, K> temp1 = Predecessor(z);
        TreeNode<T, K> temp2 = Successor(z);
        if (temp1 == null) temp1 = leftSentinel;
        if (temp2 == null) temp2 = rightSentinel;
        setPrevNext(temp1, temp2);
        counter--;
        remove(z);
    }
}