public class Update23Tree extends TwoThreeTree<Long, Float>{
    public Update23Tree() {
        super();
        MAXKEY = Long.MAX_VALUE;
        MINKEY = Long.MIN_VALUE;
    }
    public void insert(Long key, Float value){
        super.insert(key, value);
    }
}