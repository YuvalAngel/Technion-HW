public class TreeNode <T extends Comparable<T>, K>{
    private T key;
    private K value;
    private TreeNode<T, K> left,middle,right,parent;
    private TreeNode<T, K> next, prev;
    private int count = 1;
    public TreeNode(T key, K value) {
        this.value = value;
        this.key = key;
    }
    public TreeNode () {
        this.value = null;
        this.key = null;
    }

    TreeNode<T, K> getPrev() { return prev; }
    TreeNode<T, K> getNext() { return next; }
    TreeNode<T, K> getLeft() { return left; }
    TreeNode<T, K> getRight() { return right; }
    TreeNode<T, K> getParent() { return parent; }
    TreeNode<T, K> getMiddle() { return middle; }
    T getKey() { return key; }
    public K getValue() { return value; }
    public int getCount() { return count; }
    void setCount(int count) { this.count = count; }
    void setLeft(TreeNode<T, K>  left) { this.left = left; }
    void setRight(TreeNode<T, K>  right) { this.right = right; }
    void setParent(TreeNode<T, K>  parent) { this.parent = parent; }
    void setMiddle(TreeNode<T, K>  middle) { this.middle = middle; }
    void setKey(T key) { this.key = key; }
    void setNext(TreeNode<T, K>  next) { this.next = next; }
    void setPrev(TreeNode<T, K>  prev) { this.prev = prev; }
}