public class Stock implements Comparable<Stock>{
    private final String stockID;
    private final long firstUpdateTimestamp;
    private float price;
    protected Update23Tree price_history;

    Stock(String stockID, long timestamp, float price) {
        if (price <= 0)
            throw new IllegalArgumentException();
        else {
            this.stockID = stockID;
            this.price = round(price);
            price_history = new Update23Tree();
            price_history.init();
            price_history.insert(timestamp, price);
            firstUpdateTimestamp = timestamp;
        }
    }
    public float getPrice() { return round(this.price); }
    public String getStockID() { return this.stockID; }


    public void updatePrice(long timestamp, float priceDifference) {
        price_history.insert(timestamp, priceDifference);
        price = price + priceDifference;
        price = round(price);
    }
    private float round(float price) {
        float scaledPrice = price * 100;
        return Math.round(scaledPrice) / 100f;
    }

    public long getFirstUpdateTimestamp() { return firstUpdateTimestamp; }

    public boolean update_exists(long timestamp) {
        return price_history.search(timestamp) != null;
    }

    public void remove_update(long timestamp) {
        float priceDifference = price_history.search(timestamp);
        price = price - priceDifference;
        price = round(price);
        price_history.remove(timestamp);
    }

    @Override
    public int compareTo(Stock o) {
        return stockID.compareTo(o.stockID);
    }
    @Override
    public boolean equals(Object o) {
        if (o instanceof Stock) {
            Stock s = (Stock) o;
            return s.stockID.equals(this.stockID);
        }
        return false;
    }
}