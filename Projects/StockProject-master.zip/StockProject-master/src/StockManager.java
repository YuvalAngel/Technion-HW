public class StockManager {
    private final Stock23Tree stocks = new Stock23Tree();
    private final Price23Tree stockPrices = new Price23Tree();

    public StockManager() { }

    // 1. Initialize the system
    public void initStocks() {
        stocks.init();
        stockPrices.init();
    }

    // 2. Add a new stock
    public void addStock(String stockId, long timestamp, Float price) {
        Stock s = new Stock(stockId, timestamp, price);
        if (stocks.search(stockId) != null)
            throw new IllegalArgumentException();
        else {
            stocks.insert(s);
            stockPrices.insert(s);
        }
    }

    // 3. Remove a stock
    public void removeStock(String stockId) {
        Stock s = stocks.search(stockId);
        if (s == null)
            throw new IllegalArgumentException();
        else {
            stocks.remove(stockId);
            stockPrices.remove(s.getPrice(), stockId);
        }
    }

    // 4. Update a stock price
    public void updateStock(String stockId, long timestamp, Float priceDifference) {
        Stock s = stocks.search(stockId);
        if (s == null || s.update_exists(timestamp) || priceDifference == 0)
            throw new IllegalArgumentException();
        else {
            stockPrices.remove(s.getPrice(), stockId);
            s.updatePrice(timestamp, priceDifference);
            stockPrices.insert(s);
        }
    }

    // 5. Get the current price of a stock
    public Float getStockPrice(String stockId) {
        Stock s = stocks.search(stockId);
        if (s == null)
            throw new IllegalArgumentException();
        return s.getPrice();
    }

    // 6. Remove a specific timestamp from a stock's history
    public void removeStockTimestamp(String stockId, long timestamp) {
        Stock s = stocks.search(stockId);
        if (s == null || !s.update_exists(timestamp) || timestamp == s.getFirstUpdateTimestamp())
            throw new IllegalArgumentException();
        else {
            stockPrices.remove(s.getPrice(), stockId);
            s.remove_update(timestamp);
            stockPrices.insert(s);
        }
    }

    // 7. Get the amount of stocks in a given price range
    public int getAmountStocksInPriceRange(Float price1, Float price2) {
        if (price1 > price2)
            throw new IllegalArgumentException();
        else return stockPrices.getAmountStocksInPriceRange(price1, price2);
    }

    // 8. Get a list of stock IDs within a given price range
    public String[] getStocksInPriceRange(Float price1, Float price2) {
        if (price1 > price2)
            throw new IllegalArgumentException();
        else return stockPrices.getStocksInPriceRange(price1, price2);
    }

}


