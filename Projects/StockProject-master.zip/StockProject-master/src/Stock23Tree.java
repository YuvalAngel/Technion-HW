public class Stock23Tree extends TwoThreeTree<String, Stock>{
    public Stock23Tree() {
        super();
        MAXKEY = "ZZZZZZZZZZZZZZZZZZZZ";
        MINKEY = "";
    }
    public void insert(Stock stock){
        super.insert(stock.getStockID(), stock);
    }
    public void remove(String stockID){
        super.remove(stockID);
    }
}